=== GetReview ===
Contributors: refericon, mateuszbrakoniecki
Tags: reviews, opinions, woocommerce, social proof, testimonials
Requires at least: 5.1
Tested up to: 5.4
Requires PHP: 7.2
Stable Tag: 2.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Collect reviews from customers who made purchases in the store! Reward them for opinions with a photo. Show reviews on product page.
